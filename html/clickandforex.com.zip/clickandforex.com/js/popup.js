function PopupPolicy(){
	
	var w = 650;
	var h = 400;
	var l = Math.floor((screen.width-w)/2);
	var t = Math.floor((screen.height-h)/2);

	window.open("privacy.html","","width=" + w + ",height=" + h + ",top=" + t + ",left=" + l +",scrollbars=yes");
}

function PopupCentratta(){
	
	var w = 650;
	var h = 400;
	var l = Math.floor((screen.width-w)/2);
	var t = Math.floor((screen.height-h)/2);

	window.open("trattamento.html","","width=" + w + ",height=" + h + ",top=" + t + ",left=" + l +",scrollbars=yes");
}
function popupcookie(){
	
	var w = 650;
	var h = 400;
	var l = Math.floor((screen.width-w)/2);
	var t = Math.floor((screen.height-h)/2);

	window.open("cookie.html","","width=" + w + ",height=" + h + ",top=" + t + ",left=" + l +",scrollbars=yes");
}
function PopupCentrata(pagina){
	
	var w = 650;
	var h = 400;
	var l = Math.floor((screen.width-w)/2);
	var t = Math.floor((screen.height-h)/2);

	window.open(pagina,"","width=" + w + ",height=" + h + ",top=" + t + ",left=" + l +",scrollbars=yes");
}
